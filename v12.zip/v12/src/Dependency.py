import pygame
from src.resources import *

from src.StateMachine import StateMachine
from src.states.BaseState import BaseState
from src.states.StartState import StartState
from src.states.PlayerClassSelectState import PlayerClassSelectState
from src.states.PlayState import PlayState
from src.states.GameOverState import GameOverState
from src.states.VictoryState import VictoryState
# src/Dependency.py

game_state = {
    "selected_character": None  # Initially set to None, will be updated after selection
}
