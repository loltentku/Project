import pygame
import random
import sys
from src.states.BaseState import BaseState
from src.constants import *
from src.Dependency import *
from src.resources import *
from src.ShopManager import ShopManager

class MinibossManager:
    def __init__(self, play_state):
        self.play_state = play_state
        self.miniboss_encounter = False
        self.miniboss_health = 50
        self.miniboss_damage = 3
        self.player_damage = 0
        self.turns_counter = 0  # Tracks the number of turns

        # Load miniboss image
        self.miniboss_image = pygame.image.load("./graphics/forgottenguardian.png").convert_alpha()
        self.miniboss_image = pygame.transform.scale(self.miniboss_image, (160, 210))  # Adjust size as needed

        # Dice button for miniboss encounter
        self.miniboss_dice_button_rect = pygame.Rect(580, 500, 120, 50)

        self.get_coins_text_timer = 0
        self.get_coins_text = "" 
        self.coin_icon = pygame.image.load("./graphics/coin.png").convert_alpha()
        self.coin_icon = pygame.transform.scale(self.coin_icon, (35, 35))

        self.miniboss_skill_text = ""
        self.miniboss_skill_text_timer = 0  # Timer for miniboss skill message
        self.miniboss_blocking = False  # Tracks if active skill blocks player's damage

        self.roll_dice_sound = pygame.mixer.Sound("./sounds/attack.mp3")

    def start_battle(self, miniboss_health):
        """Start a battle with the miniboss."""
        print("MiniBoss battle started!")
        self.miniboss_encounter = True
        self.miniboss_health = miniboss_health

    def roll_dice_attack(self):
        self.roll_dice_sound.play()
        """Roll dice to determine player's attack on the miniboss."""
        self.player_damage = random.randint(1, 6)  # Player's base attack damage
        self.turns_counter += 1  # Increment turn counter

        if self.play_state.sword_active:
            self.player_damage *= 2  # Double damage if sword effect is active
            print(f"Sword effect active! Attack damage doubled to {self.player_damage}!")

        # MiniBoss passive skill: 20% chance to reduce 2 damage
        if random.random() < 0.2:  # 20% chance
            damage_reduction = 2
            self.player_damage = max(self.player_damage - damage_reduction, 0)
            self.miniboss_skill_text = "MiniBoss reduced 2 damage!"
            self.miniboss_skill_text_timer = pygame.time.get_ticks()
            print("MiniBoss passive skill activated: Reduced 2 damage!")

        # Apply damage to miniboss only if not blocking
        if not self.miniboss_blocking:
            self.miniboss_health -= self.player_damage
            print(f"Player attacked with {self.player_damage}! MiniBoss health: {self.miniboss_health}")
        else:
            print("MiniBoss blocked the player's attack this turn!")
            self.miniboss_blocking = False  # Reset blocking after the round

        # Check if the miniboss is defeated
        if self.miniboss_health <= 0:
            print("MiniBoss defeated!")
            self.miniboss_encounter = False
            coins_earned = random.randint(7, 12)
            self.play_state.money += coins_earned  # Add random currency for defeating the jellyfish
            self.get_coins_text = f"Forgotten Guardian killed: +{coins_earned} coins!"
            self.get_coins_text_timer = pygame.time.get_ticks() 
        else:
            self.miniboss_attack()

    def miniboss_attack(self):
        """MiniBoss's attack phase after the player's turn."""
        self.miniboss_damage = random.randint(2, 6)  # MiniBoss rolls a dice for damage

        # MiniBoss active skill: Roll a 6 to double damage and block player's damage
        if self.miniboss_damage == 6:
            self.miniboss_damage *= 2  # Double damage
            self.miniboss_blocking = True  # Block player's damage
            self.miniboss_skill_text = "MiniBoss activated skill! Double damage and blocked!"
            self.miniboss_skill_text_timer = pygame.time.get_ticks()
            print("MiniBoss active skill activated: Double damage and blocked player's attack!")
            self.play_state.character_hp -= self.miniboss_damage
            print(f"MiniBoss attacked back with {self.miniboss_damage}! Player HP: {self.play_state.character_hp}")
        else:
            self.play_state.character_hp -= self.miniboss_damage
            print(f"MiniBoss attacked back with {self.miniboss_damage}! Player HP: {self.play_state.character_hp}")

        if self.play_state.shield_active:
            self.miniboss_damage //= 2  # Halve damage if shield effect is active
            print(f"Shield effect active! MiniBoss damage reduced to {self.miniboss_damage}")


        if self.play_state.character_hp <= 0:
            print("Player defeated!")
            #self.play_state.has_won = False
            g_state_manager.Change('game-over', {})

    def handle_click(self, event_pos):
        """Handle mouse clicks during a miniboss encounter."""
        if self.miniboss_dice_button_rect.collidepoint(event_pos):
            self.roll_dice_attack()

    def update(self, dt, events):
        if self.miniboss_encounter:
            for event in events:
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:  # Left mouse button
                        if self.miniboss_dice_button_rect.collidepoint(event.pos):
                            self.roll_dice_attack()

        if self.miniboss_skill_text and pygame.time.get_ticks() - self.miniboss_skill_text_timer > 1500:
            self.miniboss_skill_text = ""
        if self.get_coins_text and pygame.time.get_ticks() - self.get_coins_text_timer > 1500:
            self.get_coins_text = ""

    def render(self, screen):
        if self.miniboss_encounter:
            overlay_image = pygame.image.load("./graphics/battle_miniboss.png").convert_alpha()
            # Scale the overlay image to fit the screen dimensions
            overlay_image = pygame.transform.scale(overlay_image, (WIDTH,HEIGHT))
            # Create a Surface for transparency
            overlay_surface = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            overlay_surface.fill((0, 0, 0, 55))  # RGBA (255, 255, 255, alpha)
            screen.blit(overlay_image, (0, 0))
            screen.blit(overlay_surface, (0, 0))
          
            # Display player and jellyfish images
            player_x = 225
            player_y = 150
            self.player_image = pygame.transform.scale(self.play_state.scaled_character_img, (250, 250))
            screen.blit(self.player_image, (player_x, player_y))

            miniboss_x = 830
            miniboss_y = 240
            screen.blit(self.miniboss_image, (miniboss_x, miniboss_y))

            # Render player and miniboss health
            font = gFonts['small']
            player_health_text = font.render(f"Player HP: {self.play_state.character_hp}", True, (0, 255, 0))
            screen.blit(player_health_text, (260, HEIGHT // 2 + 90))

            miniboss_health_text = font.render(f"MiniBoss HP: {self.miniboss_health}", True, (255, 0, 0))
            screen.blit(miniboss_health_text, (850, HEIGHT // 2 + 90))

            player_damage_text = font.render(f"Damage Dealt: {self.player_damage}", True, (255, 255, 255))
            screen.blit(player_damage_text, (250, HEIGHT // 2 + 120))

            miniboss_damage_text = font.render(f"Damage Dealt: {self.miniboss_damage}", True, (255, 255, 255))
            screen.blit(miniboss_damage_text, (850, HEIGHT // 2 + 120))

            # Render dice roll button
            pygame.draw.rect(screen, (255, 255, 255), self.miniboss_dice_button_rect)
            dice_button_text = font.render("Roll Dice", True, (0, 0, 0))
            screen.blit(dice_button_text, dice_button_text.get_rect(center=self.miniboss_dice_button_rect.center))

        # Render miniboss skill message if active
        if self.miniboss_skill_text and pygame.time.get_ticks() - self.miniboss_skill_text_timer < 2000:
            font = gFonts['small']
            miniboss_skill_surface = font.render(self.miniboss_skill_text, True, (255, 255, 0))
            screen.blit(miniboss_skill_surface, (WIDTH //2 - 250 , HEIGHT // 2 - 160))

        if self.get_coins_text:
            font = gFonts['small']
            get_coin_text_surface = font.render(self.get_coins_text, True, (255, 215, 0))
            screen.blit(self.coin_icon, (290,240))  # Position coin icon to the left
            screen.blit(get_coin_text_surface,(100, 280))
