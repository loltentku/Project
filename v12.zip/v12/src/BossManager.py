import pygame
import random
import sys
from src.states.BaseState import BaseState
from src.constants import *
from src.Dependency import *
from src.resources import *
from src.ShopManager import ShopManager


class BossManager:
    def __init__(self, play_state):
        self.play_state = play_state
        self.boss_encounter = False
        self.boss_health = 70
        self.boss_damage = 0
        self.boss_buff = 0
        self.player_damage = 0
        self.turns_counter = 0  # Tracks the number of turns

        # Load boss image
        self.boss_image = pygame.image.load("./graphics/lostmermaid.png").convert_alpha()
        self.boss_image = pygame.transform.scale(self.boss_image, (150, 230))  # Adjust size as needed

        # Dice button for boss encounter
        self.boss_dice_button_rect = pygame.Rect(580, 520, 120, 50)

        self.get_coins_text_timer = 0
        self.get_coins_text = "" 
        self.coin_icon = pygame.image.load("./graphics/coin.png").convert_alpha()
        self.coin_icon = pygame.transform.scale(self.coin_icon, (65, 65))

        self.boss_skill_text = ""
        self.boss_skill_text_timer = 0  # Timer for boss skill message

        self.roll_dice_sound = pygame.mixer.Sound("./sounds/attack.mp3")

    def start_battle(self,boss_health):
        """Start a battle with the boss."""
        print("Boss battle started!")
        self.boss_encounter = True
        self.boss_health = boss_health

    def roll_dice_attack(self):
        self.roll_dice_sound.play()
        """Roll dice to determine player's attack on the boss."""
        self.player_damage = random.randint(1, 6)  # Player's base attack damage
        self.turns_counter += 1  # Increment turn counter
        
        if self.play_state.sword_active:
            self.player_damage *= 2  # Double damage if sword effect is active
            print(f"Sword effect active! Attack damage doubled to {self.player_damage}!")

        

        # Apply damage to boss
        self.boss_health -= self.player_damage
        print(f"Player attacked with {self.player_damage}! Boss health: {self.boss_health}")

        # Increase boss damage after every 3 turns
        if self.turns_counter % 3 == 0:
            self.boss_buff += 1
            self.boss_skill_text = f"Boss damage increased! by {self.boss_buff} HP!"
            self.boss_skill_text_timer = pygame.time.get_ticks()  # Record time for skill text
            print(f"Boss damage increased! by {self.boss_buff}")
            

        # Check if the boss is defeated
        if self.boss_health <= 0:
            print("Boss defeated!")
            self.boss_encounter = False
            g_state_manager.Change('victory', {})
        else:
            self.boss_attack()

    def boss_attack(self):
        """Boss's attack phase after the player's turn."""
        self.boss_damage = random.randint(1, 4)  # Boss rolls a dice for damage

        # Boss skill: Heal if dice result is 3
        if self.boss_damage == 3:
            heal_amount = self.player_damage * 2
            self.boss_health += heal_amount
            self.boss_skill_text = f"Boss healed +{heal_amount} HP!"
            self.boss_skill_text_timer = pygame.time.get_ticks()  # Record time for skill text
            print(f"Boss skill activated! Boss healed by {heal_amount} HP.")

        if self.play_state.shield_active:
            self.boss_damage //= 2  # Halve damage if shield effect is active
            print(f"Shield effect active! Boss damage reduced to {self.boss_damage}")

        self.play_state.character_hp -= self.boss_damage + self.boss_buff
        print(f"Boss attacked back with {self.boss_damage}! Player HP: {self.play_state.character_hp}")

        if self.play_state.character_hp <= 0:
            print("Player defeated!")
            self.play_state.has_won = False
            
            g_state_manager.Change('game-over', {})


    def handle_click(self, event_pos):
        """Handle mouse clicks during a boss encounter."""
        if self.boss_dice_button_rect.collidepoint(event_pos):
            self.roll_dice_attack()

    def update(self, dt, events):
        if self.boss_encounter:
            for event in events:
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:  # Left mouse button
                        # Check if the shop button is clicked (toggle shop state)
                        if self.play_state.shop_button_rect.collidepoint(event.pos):
                            self.play_state.shop_open = not self.play_state.shop_open  # Toggle shop open state
                            return  # Return immediately to avoid other actions if shop is toggled

                        # # Handle Heal button click only if Violet is selected
                        # if self.play_state.character == 1 and self.play_state.heal_button_rect.collidepoint(event.pos):
                        #     if "heal" in self.play_state.abilities and self.play_state.abilities["heal"]["count"] > 0:
                        #         if self.play_state.character_hp < 110:  # Heal only if HP is not max
                        #             heal_amount = self.play_state.abilities["heal"]["effect"]
                        #             self.play_state.character_hp = min(self.play_state.character_hp + heal_amount, 110)
                        #             self.play_state.abilities["heal"]["count"] -= 1
                        #             print(f"Healed +{heal_amount} HP. Remaining heals: {self.play_state.abilities['heal']['count']}")
                        #         else:
                        #             print("HP is already at maximum!")
                        #     else:
                        #         print("No heals remaining!")


        if self.get_coins_text and pygame.time.get_ticks() - self.get_coins_text_timer > 1500:
            self.get_coins_text = ""
        

    def render(self, screen):
        if self.boss_encounter:
            overlay_image = pygame.image.load("./graphics/battle_boss.jpg").convert_alpha()
            # Scale the overlay image to fit the screen dimensions
            overlay_image = pygame.transform.scale(overlay_image, (WIDTH,HEIGHT))
            # Create a Surface for transparency
            overlay_surface = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            overlay_surface.fill((0, 0, 0, 55))  # RGBA (255, 255, 255, alpha)
            screen.blit(overlay_image, (0, 0))
            screen.blit(overlay_surface, (0, 0))
          
            # Display player and jellyfish images
            player_x = 225
            player_y = 150
            self.player_image = pygame.transform.scale(self.play_state.scaled_character_img, (250, 250))
            screen.blit(self.player_image, (player_x, player_y))

            boss_x = 830
            boss_y = 180
            screen.blit(self.boss_image, (boss_x, boss_y))

            # Render player and boss health
            font = gFonts['small']
            player_health_text = font.render(f"Player HP: {self.play_state.character_hp}", True, (0, 255, 0))
            screen.blit(player_health_text, (260, HEIGHT // 2 + 90))

            boss_health_text = font.render(f"Boss HP: {self.boss_health}", True, (255, 0, 0))
            screen.blit(boss_health_text, (850, HEIGHT // 2 +90))

            # Render player and boss damage
            player_damage_text = font.render(f"Damage Dealt: {self.player_damage}", True, (255, 255, 255))
            screen.blit(player_damage_text, (250, HEIGHT // 2 + 120))

            boss_damage_text = font.render(f"Damage Dealt: {self.boss_damage}", True, (255, 255, 255))
            screen.blit(boss_damage_text, (850, HEIGHT // 2 + 120))

            # Render dice roll button
            pygame.draw.rect(screen, (255, 255, 255), self.boss_dice_button_rect)
            dice_button_text = font.render("Roll dice", True, (0, 0, 0))
            screen.blit(dice_button_text, dice_button_text.get_rect(center=self.boss_dice_button_rect.center))

        # Render boss skill message if active
        if self.boss_skill_text and pygame.time.get_ticks() - self.boss_skill_text_timer < 2000:
            font = gFonts['small']
            boss_skill_surface = font.render(self.boss_skill_text, True, (255, 255, 0))
            screen.blit(boss_skill_surface, (WIDTH //2 - 200 , HEIGHT // 2 - 150))

        
        if self.play_state.character == 1:  # Violet
            font = gFonts['small']
            if "heal" in self.play_state.abilities and self.play_state.abilities["heal"]["count"] > 0:
                # Active Heal button (Fresh Green)
                pygame.draw.rect(screen, (0, 255, 0), self.play_state.heal_button_rect)
                heal_text = font.render("Heal", True, (0, 0, 0))
                screen.blit(heal_text, heal_text.get_rect(center=self.play_state.heal_button_rect.center))
            else:
                # Inactive Heal button (Gray)
                pygame.draw.rect(screen, (128, 128, 128), self.play_state.heal_button_rect)
                heal_text = font.render("Heal", True, (255, 255, 255))
                screen.blit(heal_text, heal_text.get_rect(center=self.play_state.heal_button_rect.center))
 
