import pygame
import sys
from src.states.BaseState import BaseState
from src.constants import *
from src.Dependency import *


class PlayerClassSelectState(BaseState):
    def __init__(self):
        super(PlayerClassSelectState, self).__init__()
        self.curr_character = 1  

        # Load arrow images and define rectangles for click detection
        self.l_arrow_image = pygame.image.load("./graphics/arrow_l.png").convert_alpha()
        self.r_arrow_image = pygame.image.load("./graphics/arrow_r.png").convert_alpha()
        self.l_arrow_rect = self.l_arrow_image.get_rect(center=(WIDTH / 4 - 72, HEIGHT / 2+30))
        self.r_arrow_rect = self.r_arrow_image.get_rect(center=(WIDTH - WIDTH / 4, HEIGHT / 2+30))

        # Load and scale the textbox image
        self.textbox_image = pygame.image.load("./graphics/textbox_pirate.png").convert_alpha()
        self.scaled_textbox_image = pygame.transform.scale(self.textbox_image, (700, 150))
        self.textbox_rect = self.scaled_textbox_image.get_rect(center=(WIDTH / 2, HEIGHT - HEIGHT / 5 + 7))

        self.select_button_sound = pygame.mixer.Sound('sounds/button.mp3')

    def Exit(self):
        pass

    def Enter(self, params):
        pass

    def update(self, dt, events):
        for event in events:
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                # Check if left arrow was clicked
                if self.l_arrow_rect.collidepoint(event.pos):
                    self.select_button_sound.play()
                    if self.curr_character > 1:
                        self.curr_character -= 1
                # Check if right arrow was clicked
                elif self.r_arrow_rect.collidepoint(event.pos):
                    self.select_button_sound.play()
                    if self.curr_character < 3:
                        self.curr_character += 1

            elif event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                self.select_button_sound.play()
                # Assign abilities based on the selected character
                if self.curr_character == 1:  # Violet
                    abilities = {"heal": {"count": 2, "effect": 15}}  # 2 heals, each +15 HP
                elif self.curr_character == 2:  # Ekko
                    abilities = {"poison": {"count": 1}}  # 1 poison ability
                elif self.curr_character == 3:  # Powder
                    abilities = {"double_roll": {"count": 3}}  # Roll twice, 3 uses

                # Pass the selected character index and abilities to PlayState
                g_state_manager.Change('play', {'character': self.curr_character, 'abilities': abilities})

            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                g_state_manager.Change('start', {})

    def render(self, screen):
        # Draw the transparent overlay for the background
        transparent_overlay = pygame.Surface((WIDTH, HEIGHT))
        transparent_overlay.set_alpha(130)
        transparent_overlay.fill((127, 127, 127))
        screen.blit(transparent_overlay, (0, 0))

        # Render title
        t_instruct = gFonts['medium'].render("Select your character", False, (255, 255, 255))
        rect = t_instruct.get_rect(center=(WIDTH / 2, HEIGHT / 4))
        screen.blit(t_instruct, rect)

        # Render "Enter to Select" text
        t_enter = gFonts['small'].render("Enter to Select", False, (255, 255, 255))
        rect = t_enter.get_rect(center=(WIDTH / 2, HEIGHT / 3))
        screen.blit(t_enter, rect)

        # Load and scale the character image
        character_img = character_image_list[self.curr_character - 1]
        scaled_character_img = pygame.transform.scale(character_img, (200, 200))
        rect = scaled_character_img.get_rect(midtop=(WIDTH / 2, HEIGHT / 2 - 120))
        screen.blit(scaled_character_img, rect)

        if self.curr_character == 1:
            self.l_arrow_image.set_alpha(128)
        screen.blit(self.l_arrow_image, self.l_arrow_rect)
        self.l_arrow_image.set_alpha(255)

        if self.curr_character == 3:
            self.r_arrow_image.set_alpha(128)
        screen.blit(self.r_arrow_image, self.r_arrow_rect)
        self.r_arrow_image.set_alpha(255)

        # Character name and description
        character_name = ["Violet : 100 HP", "Ekko : 110 HP", "Powder : 100 HP"][self.curr_character - 1]
        character_description = {
            1: "Ability: Heal (+15 HP, 2 uses)",
            2: "Ability: Poison (Instantly kill monster, 1 use)",
            3: "Ability: Double money when get a treasure box"
        }[self.curr_character]

        # Draw the textbox and render the character name and description
        screen.blit(self.scaled_textbox_image, self.textbox_rect.topleft)
        t_character = gFonts['small'].render(character_name, False, (106, 78, 66))
        t_character_rect = t_character.get_rect(center=(WIDTH / 2, HEIGHT - HEIGHT / 4 + 20))
        screen.blit(t_character, t_character_rect)

        t_character_description = gFonts['small'].render(character_description, False, (106, 78, 66))
        t_character_desc_rect = t_character_description.get_rect(center=(WIDTH / 2, HEIGHT - HEIGHT / 5 + 20))
        screen.blit(t_character_description, t_character_desc_rect)
