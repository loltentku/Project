from src.states.BaseState import BaseState
from src.constants import *
from src.Dependency import *
import pygame, sys

class VictoryState(BaseState):
    def __init__(self):
        super(VictoryState, self).__init__()
        self.play_again_button_image = pygame.image.load("./graphics/exit.png").convert_alpha()
        new_width = self.play_again_button_image.get_width() * 0.5 
        new_height = self.play_again_button_image.get_height() * 0.5  
        self.play_again_button_image = pygame.transform.scale(self.play_again_button_image, (new_width, new_height))
        self.play_again_button_rect = self.play_again_button_image.get_rect(center=(WIDTH / 2, HEIGHT / 2 + 100))
        
        self.win_sound = pygame.mixer.Sound('sounds/victory.mp3')

    def Exit(self):
        pass

    def Enter(self, params):
        self.win_sound.play()

    def update(self, dt, events):
        for event in events:
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # Left mouse button
                    if self.play_again_button_rect.collidepoint(event.pos):
                        g_state_manager.Change('start', {'reset': True})  # Go back to the start state

    def render(self, screen):
        # Render "Game Over" text
        t_victory = gFonts['large2'].render("Win!!", False, (255, 255, 255))
        rect = t_victory.get_rect(center=(WIDTH / 2,  HEIGHT / 2 - 6))
        screen.blit(t_victory, rect)

        screen.blit(self.play_again_button_image, self.play_again_button_rect.topleft)
