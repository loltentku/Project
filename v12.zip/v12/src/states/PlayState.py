import pygame
import sys
import random
from src.states.BaseState import BaseState
from src.constants import *
from src.Dependency import *
from src.resources import *
from src.JellyfishManager import JellyfishManager 
from src.SwordfishManager import SwordfishManager
from src.AnglerfishManager import AnglerfishManager
from src.EelManager import EelManager
from src.OctopusManager import OctopusManager
#from src.MonsterManager import MonsterManager  # Import MonsterManager for handling monster logic
from src.ShopManager import ShopManager
from src.BossManager import BossManager
from src.MinibossManager import MinibossManager


class PlayState(BaseState):
    def __init__(self):
        super(PlayState, self).__init__()
        self.dice_frame_time = 1000  # Time interval between dice animation frames (in ms)
        self.last_frame_update_time = 0  # Tracks when the last frame was updated
        self.dice_images = []
        self.dice_animation_images = []
        self.final_dice_image = None
        self.is_rolling = False
        self.roll_animation_start_time = 0
        self.rolling_images_counter = 0
        self.animation_duration = 1000  # Animation duration in milliseconds
        self.initialize_game_state()

        self.dice_rolling_sound = pygame.mixer.Sound('sounds/roll_aud.mp3')
        self.dice_stop_sound = pygame.mixer.Sound('sounds/roll_stop_aud.mp3')

        # Dice button setup
        self.roll_dice_button_image = pygame.image.load("./graphics/rd_button.png").convert_alpha()
        self.roll_dice_button_image = pygame.transform.scale(self.roll_dice_button_image, (180, 80))  # Adjust size
        self.roll_dice_button_rect = self.roll_dice_button_image.get_rect(topleft=(210, 530))  # Position the button

        self.collect_coin_sound = pygame.mixer.Sound('sounds/collectcoins.mp3')
        self.collect_health_sound = pygame.mixer.Sound('sounds/heal.mp3')
        #self.lost_health_sound = pygame.mixer.Sound('sounds/heal.mp3')
        self.button_sound = pygame.mixer.Sound('sounds/button.mp3')

    def initialize_game_state(self):
        # Grid setup
        self.grid_image = pygame.image.load("./graphics/grid.png").convert_alpha()
        new_width = int(self.grid_image.get_width() * 0.45)
        new_height = int(self.grid_image.get_height() * 0.45)
        self.grid_image = pygame.transform.scale(self.grid_image, (new_width, new_height))

        self.cell_width = self.grid_image.get_width() // 10
        self.cell_height = self.grid_image.get_height() // 10

        # Character setup
        self.character_x = 0
        self.character_y = 9
        self.steps_to_move = 0
        self.is_moving = False
        self.has_won = False
        self.money = 0  # Player's currency

        self.shop_open = False  # Flag to check if the shop is open
        self.shop_page = 1

        self.roll_dice_active = True

        # Buttons
        #self.button_rect = pygame.Rect(240, 530, 120, 50)  # Dice button
        self.shop_button_rect = pygame.Rect(20, 20, 120, 50)  # Shop button
        self.heal_button_rect = pygame.Rect(240, 130, 120, 50)
        self.poison_button_rect = pygame.Rect(250, 520, 120, 50)
        #self.double_roll_button_rect = pygame.Rect(250, 300, 120, 50)

        # Buttons
        self.small_potion_button_rect = pygame.Rect(600, 240, 100, 50)
        self.large_potion_button_rect = pygame.Rect(600, 340, 100, 50)
        self.shield_button_rect = pygame.Rect(600, 440, 100, 50)
        self.sword_button_rect = pygame.Rect(600, 540, 100, 50)
        #self.shield_button_rect = pygame.Rect(600, 240, 100, 50)  

        self.extra_step_active = False
        self.sword_active = False
        self.shield_active = False

        self.close_button_rect = pygame.Rect(770, 625, 100, 40)


        self.dice_result = 0 
        self.health_increase_text = ""  # Message for health increase
        self.health_increase_text_timer = 0 

        self.treasure_text = ""  # Message for coin collection
        self.treasure_text_timer = 0  # Timer for message display
        self.coin_icon = pygame.image.load("./graphics/coin.png").convert_alpha()
        self.coin_icon = pygame.transform.scale(self.coin_icon, (35, 35))
        self.health_decrease_text = ""  # Message for health decrease
        self.health_decrease_text_timer = 0

        # Grid layout
        self.grid = [
            ["octopus", "empty", "health", "empty", "empty", "empty", "octopus", "empty", "empty", "boss"],
            ["empty", "treasure", "empty", "empty", "empty", "octopus", "empty", "trap", "empty", "empty"],
            ["empty", "empty", "empty", "treasure", "empty", "empty", "eel", "empty", "empty", "empty"],
            ["empty", "empty", "empty", "empty", "eel", "empty", "treasure", "empty", "empty", "eel"],
            ["empty", "empty", "empty", "empty", "trap", "empty", "anglerfish", "empty", "empty", "empty"],
            ["empty", "empty", "empty", "anglerfish", "empty", "empty", "treasure", "empty", "empty", "miniboss"],
            ["swordfish", "empty", "empty", "treasure", "empty", "empty", "empty", "health", "empty", "trap"],
            ["empty", "empty", "empty", "empty", "health", "swordfish", "empty", "empty", "treasure", "empty"],
            ["health", "empty", "jellyfish", "empty", "empty", "treasure", "empty", "empty", "jellyfish", "empty"],
            ["empty", "empty", "empty", "treasure", "empty", "jellyfish", "health", "empty", "empty", "empty"],
            #["empty", "boss", "boss", "boss", "boss", "boss", "boss", "empty", "empty", "empty"]

        ]

        self.character_img = None
        self.scaled_character_img = None

        # Managers
        self.shop_manager = ShopManager(self)
        self.jellyfish_manager = JellyfishManager(self)
        self.swordfish_manager = SwordfishManager(self)
        self.anglerfish_manager = AnglerfishManager(self)
        self.eel_manager = EelManager(self)
        self.octopus_manager = OctopusManager(self)
        self.boss_manager = BossManager(self)
        self.miniboss_manager = MinibossManager(self)
          # Create ShopManager instance

        # Target dice size
        dice_size = (100, 100)  # Increase size to 150x150 pixels

        # Load dice face images (1-6) and scale
        for num in range(1, 7):
            dice_image = pygame.image.load(f"./graphics/dice/{num}.png").convert_alpha()
            scaled_dice_image = pygame.transform.scale(dice_image, dice_size)
            self.dice_images.append(scaled_dice_image)

        # Load dice animation images and scale
        for num in range(1, 7):
            animation_image = pygame.image.load(f"./graphics/diceanimation/roll{num}.png").convert_alpha()
            scaled_animation_image = pygame.transform.scale(animation_image, dice_size)
            self.dice_animation_images.append(scaled_animation_image)

        # Initialize last step time for character movement
        self.last_step_time = 0
       

    def Exit(self):
        pass

    def Enter(self, params):
        self.initialize_game_state()
        self.character = params["character"]
        self.abilities = params.get("abilities", {})

        # Character HP based on selected character
        if self.character == 1:  # Warrior
            self.character_hp = 100
        elif self.character == 2:  # ekko
            self.character_hp = 110
        elif self.character == 3:  # powder
            self.character_hp = 100

        self.character_img = character_image_list[self.character - 1]
        self.scaled_character_img = pygame.transform.scale(self.character_img, (90, 90))

    def roll_dice(self):
        """Start the dice rolling process if no animation is currently running."""
        if self.roll_dice_active and not self.is_rolling:  # Only allow rolling if not already rolling
            self.start_dice_animation()  # Start the dice animation
            if not self.has_won:
                steps_to_target = self.calculate_steps_to_target(9, 5)
                steps_to_end = self.calculate_steps_to_target(9, 0)

                if self.character_y > 5 or (self.character_y == 5 and self.character_x < 9):
                    if self.dice_result > steps_to_target:
                        self.dice_result = steps_to_target
                else:
                    if self.dice_result > steps_to_end:
                        self.dice_result = steps_to_end

                # Standard roll logic for normal gameplay
                self.dice_result = self.dice_result
                self.steps_to_move = self.dice_result  # Set steps based on dice result

                self.is_moving = True  # Start moving the character
                print(f"Dice rolled: {self.dice_result}, moving {self.steps_to_move} steps")


    def start_dice_animation(self):
        """Start the dice rolling animation."""
        self.is_rolling = True  # Enable rolling animation
        self.roll_animation_start_time = pygame.time.get_ticks()
        self.rolling_images_counter = 0  # Start from the first frame
        self.last_frame_update_time = pygame.time.get_ticks()

        # Play the rolling dice sound effect
        self.dice_rolling_sound.play(-1)  # Loop the rolling sound
        # Generate the dice result (1 to 6) and set the corresponding final dice image
        self.dice_result = random.randint(1, 6)
        self.final_dice_image = self.dice_images[self.dice_result - 1]  # Convert to 0-based index

        # Debugging to ensure correct assignment
        print(f"Starting dice animation. Dice Result: {self.dice_result}, Final Dice Image Set.")



    def update_dice_animation(self):
        """Update the dice rolling animation for a single loop."""
        if self.is_rolling:
            current_time = pygame.time.get_ticks()

            # Update the animation frame only if enough time has passed
            frame_interval = 100  # Duration for each frame in milliseconds (adjust for slower animation)
            if current_time - self.last_frame_update_time >= frame_interval:
                self.rolling_images_counter += 1  # Increment the frame counter
                self.last_frame_update_time = current_time  # Record the time of this update

            # Stop the animation after one full loop through the frames
            if self.rolling_images_counter >= len(self.dice_animation_images):
                self.is_rolling = False  # Stop the animation
                self.rolling_images_counter = len(self.dice_animation_images) - 1  # Show the last frame
                # Stop the rolling sound and play the stopping sound
                self.dice_rolling_sound.stop()
                self.dice_stop_sound.play()
                print(f"Dice animation stopped. Final Result: {self.dice_result}")





    def render_dice(self, screen):
        """Render the dice rolling animation or final dice face."""
        dice_position = (250, 400)  # Position to display the dice (adjust as needed)

        # Check if a monster encounter is active; skip rendering dice if true
        monster_encounter = (
            self.jellyfish_manager.jellyfish_encounter or
            self.swordfish_manager.swordfish_encounter or
            self.anglerfish_manager.anglerfish_encounter or
            self.eel_manager.eel_encounter or
            self.octopus_manager.octopus_encounter or
            self.miniboss_manager.miniboss_encounter or
            self.boss_manager.boss_encounter
        )

        if monster_encounter:
            # Do not render dice during monster encounters
            return

        if self.is_rolling:
            # Render the current animation frame
            current_frame = self.rolling_images_counter % len(self.dice_animation_images)
            screen.blit(self.dice_animation_images[current_frame], dice_position)
        else:
            # Render the final dice face
            if self.final_dice_image:
                screen.blit(self.final_dice_image, dice_position)


    def calculate_steps_to_target(self, target_x, target_y):
        """Calculate the exact number of steps required to reach a specific grid (target_x, target_y)."""
        # Steps remaining in the current row to reach target_x
        remaining_in_row = target_x - self.character_x if self.character_y == target_y else max(0, 9 - self.character_x + 1)

        # Rows to traverse to target_y
        rows_to_traverse = abs(self.character_y - target_y)

        # Total steps required
        total_steps = remaining_in_row + (rows_to_traverse * 10)
        return total_steps

    def move_character(self):
        """Move the character step by step with a delay between steps."""
        if self.steps_to_move > 0:
            current_time = pygame.time.get_ticks()

            # Time interval between steps (in milliseconds)
            step_delay = 300  # Adjust to match the dice animation speed

            if current_time - self.last_step_time >= step_delay:
                self.last_step_time = current_time  # Update the time of the last step

                if self.character_x == 9 and self.character_y == 0:
                    self.is_moving = False
                    return

                if self.character_x < 9:
                    self.character_x += 1
                else:
                    self.character_x = 0
                    if self.character_y > 0:
                        self.character_y -= 1
                    else:
                        self.is_moving = False
                        return

                self.steps_to_move -= 1

                # Check for events after each step
                if self.steps_to_move == 0:
                    self.is_moving = False
                    self.handle_event()


    def handle_event(self):
        tile_type = self.grid[self.character_y][self.character_x]
        if tile_type == "jellyfish":
            self.jellyfish_manager.start_battle(10)
        elif tile_type == "swordfish":
            self.swordfish_manager.start_battle(20)
        elif tile_type == "anglerfish":
            self.anglerfish_manager.start_battle(30)
        elif tile_type == "eel":
            self.eel_manager.start_battle(40)
        elif tile_type == "octopus":
            self.octopus_manager.start_battle(60)
        elif tile_type == "treasure":
            self.collect_treasure()
        elif tile_type == "health":
            self.increase_health()
        elif tile_type == "trap":
            self.decrease_health()
        elif tile_type == "miniboss":
            self.miniboss_manager.start_battle(50)
        elif tile_type == "boss":
            self.boss_manager.start_battle(99)


    def collect_treasure(self):
        self.collect_coin_sound.play()
        coins_found = random.randint(7, 17)  # Random coin amount
        if self.character == 3:  # Check if Powder is the active character
            coins_found *= 2  # Double the coins for Powder
            print(f"[DEBUG] Powder activated Treasure Hunter skill! Original coins: {coins_found // 2}, Doubled coins: {coins_found}")
        else:
            print(f"[DEBUG] Collected {coins_found} coins (No skill activated).")

        self.money += coins_found
        self.treasure_text = f"+{coins_found} Coins!"
        self.treasure_text_timer = pygame.time.get_ticks()
        print(f"[DEBUG] Current money after treasure: {self.money}")

    def increase_health(self):
        self.collect_health_sound.play()
        hp_increase = random.randint(10, 20)
        self.character_hp += hp_increase
        self.health_increase_text = f"Health increased: +{hp_increase} HP"
        self.health_increase_text_timer = pygame.time.get_ticks()
        print(f"Health increased by {hp_increase}. Current HP: {self.character_hp}")

    def decrease_health(self):
        """Handle health decrease."""
        #self.lost_health_sound.play()
        hp_decrease = random.randint(10, 20)
        self.character_hp -= hp_decrease
        self.health_decrease_text = f"-{hp_decrease} HP"
        self.health_decrease_text_timer = pygame.time.get_ticks()  # Record the time
        print(f"Health decreased by {hp_decrease}. Current HP: {self.character_hp}")

    def update(self, dt, events):
        for event in events:
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    pass
                    

                if self.jellyfish_manager.jellyfish_encounter:
                    self.jellyfish_manager.handle_click(event.pos)
                elif self.swordfish_manager.swordfish_encounter:
                    self.swordfish_manager.handle_click(event.pos)
                elif self.anglerfish_manager.anglerfish_encounter:
                    self.anglerfish_manager.handle_click(event.pos)
                elif self.eel_manager.eel_encounter:
                    self.eel_manager.handle_click(event.pos)
                elif self.octopus_manager.octopus_encounter:
                    self.octopus_manager.handle_click(event.pos)
                elif self.miniboss_manager.miniboss_encounter:
                    self.miniboss_manager.handle_click(event.pos)
                elif self.boss_manager.boss_encounter:
                    self.boss_manager.handle_click(event.pos)
                elif self.shop_manager.shop_open:
                    self.shop_manager.handle_shop_click(event)
                elif self.roll_dice_button_rect.collidepoint(event.pos) and not self.is_moving:
                    self.button_sound.play()
                    self.roll_dice()
                elif self.shop_button_rect.collidepoint(event.pos):
                    self.button_sound.play()
                    self.shop_manager.shop_open = not self.shop_manager.shop_open
                    

                #activate / deactivate roll dice for moving 
                if self.jellyfish_manager.jellyfish_encounter == True:
                    self.roll_dice_active = False
                elif self.swordfish_manager.swordfish_encounter == True:
                    self.roll_dice_active = False
                elif self.anglerfish_manager.anglerfish_encounter == True:
                    self.roll_dice_active = False
                elif self.eel_manager.eel_encounter == True:
                    self.roll_dice_active = False
                elif self.octopus_manager.octopus_encounter == True:
                    self.roll_dice_active = False
                elif self.boss_manager.boss_encounter == True:
                    self.roll_dice_active = False
                elif self.miniboss_manager.miniboss_encounter == True:
                    self.roll_dice_active = False
                elif self.shop_manager.shop_open:
                    self.roll_dice_active = False
                else:
                    self.roll_dice_active = True

        if self.is_moving:
            self.move_character()

        self.jellyfish_manager.update(dt,events)
        self.swordfish_manager.update(dt,events)
        self.anglerfish_manager.update(dt,events)
        self.eel_manager.update(dt,events)
        self.octopus_manager.update(dt,events)
        self.miniboss_manager.update(dt,events)
        self.boss_manager.update(dt,events)

        self.update_dice_animation()

        if self.shop_manager.shop_open:
            self.shop_manager.update_shopkeeper_animation()

    def render(self, screen):
        transparent_overlay = pygame.Surface((WIDTH, HEIGHT))
        transparent_overlay.set_alpha(140)
        transparent_overlay.fill((127, 127, 127))
        screen.blit(transparent_overlay, (0, 0))
        screen.blit(self.grid_image, (600, 60))

        font = gFonts['medium']
        hp_text = font.render(f"HP: {self.character_hp}", True, (0, 255, 0))
        screen.blit(hp_text, (250, 70))

        self.shop_button_image = pygame.image.load("./graphics/shop.png").convert_alpha()
        self.shop_button_image = pygame.transform.scale(self.shop_button_image, (70, 70))  # Adjust size as needed
        self.shop_button_rect = self.shop_button_image.get_rect(topleft=(30, 30))  # Position of the button

        screen.blit(self.shop_button_image, self.shop_button_rect.topleft)

        character_pixel_x = 590 + (self.character_x * self.cell_width)
        character_pixel_y = 45  + (self.character_y * self.cell_height) - 20

        if self.character == 1:  # Violet
            if "heal" in self.abilities and self.abilities["heal"]["count"] > 0:
                # Active Heal button (Fresh Green)
                pygame.draw.rect(screen, (0, 255, 0), self.heal_button_rect)
                heal_text = font.render("Heal", True, (0, 0, 0))
            else:
                # Inactive Heal button (Gray)
                pygame.draw.rect(screen, (128, 128, 128), self.heal_button_rect)
                heal_text = font.render("Heal", True, (255, 255, 255))
            screen.blit(heal_text, heal_text.get_rect(center=self.heal_button_rect.center))  

        # Draw the "Roll Dice" button
        if not self.has_won:  # Hide buttons if the player has won
            font = gFonts['small']
            # Render the button image
            screen.blit(self.roll_dice_button_image, self.roll_dice_button_rect.topleft)

            # Render the button text
            button_text = font.render("Roll Dice", True, (0, 0, 0))
            screen.blit(button_text, button_text.get_rect(center=self.roll_dice_button_rect.center))


        if self.scaled_character_img:
            screen.blit(self.scaled_character_img, (character_pixel_x, character_pixel_y))

        if self.health_increase_text and pygame.time.get_ticks() - self.health_increase_text_timer < 2000:
            font = gFonts['small']
            health_text_surface = font.render(self.health_increase_text, True, (0, 255, 0))
            screen.blit(health_text_surface, (170, 250))  # Adjust position as needed

        # Clear the text after the timer ends
        if pygame.time.get_ticks() - self.health_increase_text_timer >= 2000:
            self.health_increase_text = ""
        
        if self.treasure_text and pygame.time.get_ticks() - self.treasure_text_timer < 2000:
            font = gFonts['small']
            treasure_text_surface = font.render(self.treasure_text, True, (255, 215, 0))
            # Position the coin icon and text
            screen.blit(self.coin_icon, (225, 240))  # Adjust position for the coin icon
            screen.blit(treasure_text_surface, (260, 250))  # Adjust position for the text

        # Clear the text after the timer ends
        if pygame.time.get_ticks() - self.treasure_text_timer >= 2000:
            self.treasure_text = ""

        if self.health_decrease_text and pygame.time.get_ticks() - self.health_decrease_text_timer < 2000:
            font = gFonts['small']
            decrease_text_surface = font.render(self.health_decrease_text, True, (255, 0, 0))
            # Position the health decrease message
            screen.blit(decrease_text_surface, (250, 250))  # Adjust position for the text

        # Clear the text after the timer ends
        if pygame.time.get_ticks() - self.health_decrease_text_timer >= 2000:
            self.health_decrease_text = ""

        self.jellyfish_manager.render(screen)
        self.swordfish_manager.render(screen)
        self.eel_manager.render(screen)
        self.anglerfish_manager.render(screen)
        self.octopus_manager.render(screen)
        self.miniboss_manager.render(screen)
        self.boss_manager.render(screen)
        if self.shop_manager.shop_open:
            self.shop_manager.render_shop(screen)
        else:
            self.render_dice(screen)