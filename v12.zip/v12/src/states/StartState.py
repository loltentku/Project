from src.states.BaseState import BaseState
import pygame, sys
from src.constants import *
from src.Dependency import *

class StartState(BaseState):
    def __init__(self):
        super(StartState, self).__init__()

        self.start_button_image = pygame.image.load("./graphics/start.png").convert_alpha()
        new_width = self.start_button_image.get_width() * 0.5 
        new_height = self.start_button_image.get_height() * 0.5  
        self.start_button_image = pygame.transform.scale(self.start_button_image, (new_width, new_height))
        self.start_button_rect = self.start_button_image.get_rect(center=(WIDTH / 2, HEIGHT / 2 + 100))
        self.reset_game()

        self.start_button_sound = pygame.mixer.Sound('sounds/button.mp3')

    def reset_game(self):
        # Initialize/reset any game variables, such as player health, score, etc.
        self.character_x = 0
        self.character_y = 9  # row 9 for bottom-left
        self.steps_to_move = 0  # Number of steps from dice roll
        self.is_moving = False  # Whether the character is currently moving
        self.has_won = False  # Flag to track if the player has won
        self.money = 0 
        self.button_rect = pygame.Rect(250, 70, 120, 50)  # Position and size of button
        self.dice_result = 0
        self.grid = [
            ["monster", "empty", "monster", "treasure", "health", "empty", "monster", "empty", "treasure", "health"],
            ["empty", "monster", "empty", "treasure", "empty", "monster", "health", "empty", "monster", "treasure"],
            ["empty", "monster", "empty", "treasure", "empty", "monster", "health", "empty", "monster", "treasure"],
            ["empty", "monster", "empty", "treasure", "empty", "monster", "health", "empty", "monster", "treasure"],
            ["empty", "monster", "empty", "treasure", "empty", "monster", "health", "empty", "monster", "treasure"],
            ["empty", "monster", "empty", "treasure", "empty", "monster", "health", "empty", "monster", "treasure"],
            ["empty", "monster", "empty", "treasure", "empty", "monster", "health", "empty", "monster", "treasure"],
            ["empty", "monster", "empty", "treasure", "empty", "monster", "health", "empty", "monster", "treasure"],
            ["empty", "monster", "empty", "treasure", "empty", "monster", "health", "empty", "monster", "treasure"],
            ["start", "monster", "empty", "treasure", "empty", "monster", "health", "empty", "monster", "treasure"]
        ]

    def Exit(self):
        pass

    def Enter(self, params):
        if params.get('reset', False):
            self.reset_game()

    def render(self, screen):
        # Render title
        #t_title = gFonts['large2'].render("Dicegeon", False, (229, 184, 11))
        #rect = t_title.get_rect(center=(WIDTH / 2, HEIGHT / 2 - 6))
        #screen.blit(t_title, rect)
        title_image = pygame.image.load("./graphics/title.png").convert_alpha()
    
        # Scale the image if needed (optional)
        title_image = pygame.transform.scale(title_image, (750, 210))  # Adjust dimensions as needed

        # Center the title on the screen
        rect = title_image.get_rect(center=(WIDTH / 2, HEIGHT / 2 - 40))
        screen.blit(title_image, rect.topleft)
             
        screen.blit(self.start_button_image, self.start_button_rect.topleft)



    def update(self, dt, events):
        for event in events:
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # Left mouse button
                    mouse_pos = pygame.mouse.get_pos()
                    if self.start_button_rect.collidepoint(mouse_pos):
                        self.start_button_sound.play()
                        g_state_manager.Change('class-select', {})
