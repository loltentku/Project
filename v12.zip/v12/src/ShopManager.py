import pygame
import sys
import random
from src.states.BaseState import BaseState
from src.constants import *
from src.Dependency import *
from src.resources import *


class ShopManager:
    def __init__(self, play_state):
        self.play_state = play_state
        self.shop_open = False
        self.shop_page = 1

        new_width = 500  # Desired width
        new_height = 500  # Desired height


        # Animation setup for shopkeeper
        self.shopkeeper_images = [
            pygame.transform.scale(
                pygame.image.load(f"./graphics/shopkeeper/{i}.png").convert_alpha(),
                (new_width, new_height)
            )
            for i in range(1, 5)
        ]


        self.shopkeeper_frame_time = 200  # Duration of each frame in milliseconds
        self.shopkeeper_last_frame_time = pygame.time.get_ticks()
        self.current_shopkeeper_frame = 0

        # Load and upscale the shop overlay image
        original_shop_overlay = pygame.image.load("./graphics/paper.png").convert_alpha()
        self.shop_overlay_image = pygame.transform.scale(original_shop_overlay, (700, 600))  # New dimensions

        # Set position for the overlay
        self.overlay_position = (500, 60)  # (x, y) coordinates for the top-left corner

        # Load the frame image
        original_frame_image = pygame.image.load("./graphics/itemslot.png").convert_alpha()
        self.frame_image = pygame.transform.scale(original_frame_image, (580, 105))  # Scale the frame

        # Set positions for the frames around items
        self.small_potion_frame_position = (555, 160)
        self.large_potion_frame_position = (555, 280)
        self.sword_frame_position = (555, 400)
        self.shield_frame_position = (555, 520)

        # Load the close button image
        original_close_button = pygame.image.load("./graphics/close.png").convert_alpha()
        self.close_button_image = pygame.transform.scale(original_close_button, (60, 60))  # Resize if needed

        # Set position for the close button using (x, y)
        self.close_button_rect = self.close_button_image.get_rect()
        self.close_button_rect.topleft = (1100, 80)  # Specify the position directly

        # Load and upscale item name images
        self.small_potion_name_image = pygame.transform.scale(
            pygame.image.load("./graphics/items/Spotion.png").convert_alpha(),
            (50, 50)
        )
        self.large_potion_name_image = pygame.transform.scale(
            pygame.image.load("./graphics/items/Lpotion.png").convert_alpha(),
            (50, 50)
        )
        self.sword_name_image = pygame.transform.scale(
            pygame.image.load("./graphics/items/Sword.png").convert_alpha(),
            (50, 50)
        )
        self.shield_name_image = pygame.transform.scale(
            pygame.image.load("./graphics/items/Shield.png").convert_alpha(),
            (50, 50)
        )

        # Define positions for item name images
        self.small_potion_name_position = (730, 185)
        self.large_potion_name_position = (730, 305)
        self.sword_name_position = (730, 425)
        self.shield_name_position = (730, 545)

        # Load the "Buy" button image
        original_buy_button = pygame.image.load("./graphics/buy.png").convert_alpha()
        self.buy_button_image = pygame.transform.scale(original_buy_button, (120, 60))  # Resize as needed

        # Set positions for the "Buy" buttons
        self.small_potion_button_rect = self.buy_button_image.get_rect(topleft=(590, 180))
        self.large_potion_button_rect = self.buy_button_image.get_rect(topleft=(590, 300))
        self.sword_button_rect = self.buy_button_image.get_rect(topleft=(590, 420))
        self.shield_button_rect = self.buy_button_image.get_rect(topleft=(590, 540))

        # Load the "Your Money" image and scale it
        original_your_money_image = pygame.image.load("./graphics/coin.png").convert_alpha()
        self.your_money_image = pygame.transform.scale(original_your_money_image, (50, 50))  # Set new dimensions (width, height)
        self.your_money_rect = self.your_money_image.get_rect(topleft=(540, 95))  # Set position for the image

        self.item_price = pygame.transform.scale(original_your_money_image, (50, 50))  # Set new dimensions (width, height)
        self.small_potion_price_position = (800, 185)
        self.large_potion_price_position = (800, 305)
        self.sword_price_position = (800, 425)
        self.shield_price_position = (800, 545)

        self.buy_sound = pygame.mixer.Sound("./sounds/buy.mp3")

    def update_shopkeeper_animation(self):
        """Update the shopkeeper animation frame based on elapsed time."""
        current_time = pygame.time.get_ticks()
        if current_time - self.shopkeeper_last_frame_time >= self.shopkeeper_frame_time:
            self.shopkeeper_last_frame_time = current_time
            self.current_shopkeeper_frame = (self.current_shopkeeper_frame + 1) % len(self.shopkeeper_images)


    def handle_shop_click(self, event):
        """Handle mouse clicks in the shop interface."""
        if self.close_button_rect.collidepoint(event.pos):
            self.play_state.button_sound.play()
            self.shop_open = False
            print("Shop closed.")


        if self.shop_page == 1:
            if self.small_potion_button_rect.collidepoint(event.pos) and self.play_state.money >= 5:
                self.buy_sound.play()
                self.play_state.money -= 5
                self.play_state.character_hp += 10
                print("Bought Small Potion: +10 HP")
            elif self.large_potion_button_rect.collidepoint(event.pos) and self.play_state.money >= 10:
                self.buy_sound.play()
                self.play_state.money -= 10
                self.play_state.character_hp += 30
                print("Bought Large Potion: +30 HP")
            elif self.shield_button_rect.collidepoint(event.pos) and self.play_state.money >= 30:
                self.buy_sound.play()
                self.play_state.money -= 30
                self.play_state.shield_active = True
                print("Bought Shield: Reduces damage by 50%!")
            elif self.sword_button_rect.collidepoint(event.pos) and self.play_state.money >= 30:
                self.buy_sound.play()
                self.play_state.money -= 30
                self.play_state.sword_active = True
                print("Bought Sword: Attack rolls doubled!")

    def render_shop(self, screen):
        # Draw shop overlay
        overlay = pygame.Surface((WIDTH, HEIGHT))
        overlay.set_alpha(200)
        overlay.fill((0, 0, 0))
        screen.blit(overlay, (0, 0))


        # Draw the upscaled shop overlay at the specified position
        screen.blit(self.shop_overlay_image, self.overlay_position)

        
        font = gFonts['small']

        # Display current shopkeeper animation frame
        shopkeeper_img = self.shopkeeper_images[self.current_shopkeeper_frame]
        screen.blit(shopkeeper_img, (10, 180))

        # Draw the "Your Money" image
        screen.blit(self.your_money_image, self.your_money_rect.topleft)

        # Draw the amount of money as text next to the image
        font = gFonts['pixel_s']
        money_amount_text = font.render(str(self.play_state.money), True, (255, 255, 0))
        screen.blit(money_amount_text, (self.your_money_rect.right + 10, self.your_money_rect.top + 10))

        # Draw frames around each item
        screen.blit(self.frame_image, self.small_potion_frame_position)
        screen.blit(self.frame_image, self.large_potion_frame_position)
        screen.blit(self.frame_image, self.sword_frame_position)
        screen.blit(self.frame_image, self.shield_frame_position)

        # Draw item name images
        screen.blit(self.small_potion_name_image, self.small_potion_name_position)
        screen.blit(self.large_potion_name_image, self.large_potion_name_position)
        screen.blit(self.sword_name_image, self.sword_name_position)
        screen.blit(self.shield_name_image, self.shield_name_position)
        
        # Draw the coin image for item
        screen.blit(self.item_price, self.small_potion_price_position)
        screen.blit(self.item_price, self.large_potion_price_position)
        screen.blit(self.item_price, self.sword_price_position)
        screen.blit(self.item_price, self.shield_price_position)

        font = gFonts['small']

        # Draw price of item
        item_1_price = font.render('5', True, (0, 0, 0))
        item_2_price = font.render('10', True, (0, 0, 0))
        item_3_price = font.render('30', True, (0, 0, 0))
        item_4_price = font.render('30', True, (0, 0, 0))

        screen.blit(item_1_price, (818, 200))
        screen.blit(item_2_price, (810, 320))
        screen.blit(item_3_price, (810, 440))
        screen.blit(item_4_price, (810, 560))

        small_potion_text = font.render("+10 HP", True, (0, 0, 0))
        large_potion_text = font.render("+30 HP", True, (0, 0, 0))
        sword_text = font.render("DMG x2", True, (0, 0, 0))
        shield_text = font.render("DMG receive -50%", True, (0, 0, 0))


        screen.blit(small_potion_text, (860, 200))
        screen.blit(large_potion_text, (860, 320))
        screen.blit(sword_text, (860, 440))
        screen.blit(shield_text, (860, 560))



        # Draw "Buy" buttons
        screen.blit(self.buy_button_image, self.small_potion_button_rect.topleft)
        screen.blit(self.buy_button_image, self.large_potion_button_rect.topleft)
        screen.blit(self.buy_button_image, self.sword_button_rect.topleft)
        screen.blit(self.buy_button_image, self.shield_button_rect.topleft)




        # Draw the close button image
        screen.blit(self.close_button_image, self.close_button_rect.topleft)









