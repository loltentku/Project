from src.states.BaseState import BaseState

class StateMachine:
    def __init__(self):
        self.current = None  # Will hold the current state
        self.states = {}  # Holds the states dictionary

    def SetStates(self, states):
        """ Set the available states and ensure the initial state is set. """
        self.states = states
        if 'start' in self.states:  # Set 'start' state as the initial state
            self.current = self.states['start']
            print("Initial state set to 'start'.")
        else:
            print("Error: 'start' state not found!")

    def Change(self, state_name, enter_params):
        """ Change the current state to a new state. """
        if state_name in self.states:
            if self.current:
                self.current.Exit()  # Exit the current state

            self.current = self.states[state_name] # Pass params during instantiation
            self.current.Enter(enter_params)  # Enter the new state

    def update(self, dt, events):
        """ Update the current state. """
        if self.current:
            self.current.update(dt, events)
        else:
            print("Error: No current state to update!")

    def render(self, screen):
        """ Render the current state. """
        if self.current:
            self.current.render(screen)
        else:
            print("Error: No current state to render!")

    def SetScreen(self, screen):
        """ Set the screen for rendering. """
        self.screen = screen
