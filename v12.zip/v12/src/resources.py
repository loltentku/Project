import pygame
from src.Util import SpriteManager
from src.StateMachine import StateMachine

pygame.font.init()

g_state_manager = StateMachine()

sprite_collection = SpriteManager().spriteCollection

violet_idle_image_list = [sprite_collection["violet_idle_1"].image, sprite_collection["violet_idle_2"].image,
                          sprite_collection["violet_idle_3"].image, sprite_collection["violet_idle_4"].image]

ekko_idle_image_list = [sprite_collection["ekko_idle_1"].image, sprite_collection["ekko_idle_2"].image,
                          sprite_collection["ekko_idle_3"].image, sprite_collection["ekko_idle_4"].image]

powder_idle_image_list = [sprite_collection["powder_idle_1"].image, sprite_collection["powder_idle_2"].image,
                          sprite_collection["powder_idle_3"].image, sprite_collection["powder_idle_4"].image]


character_image_list = [sprite_collection["violet_idle_1"].image, sprite_collection["ekko_idle_1"].image, sprite_collection["powder_idle_1"].image]

gFonts = {
        'small': pygame.font.Font('./fonts/minecraft.ttf', 28),
        'medium': pygame.font.Font('./fonts/minecraft.ttf',40),
        'large': pygame.font.Font('./fonts/minecraft.ttf', 90),
        'large2': pygame.font.Font('./fonts/font_title.ttf', 95),
        'pixel_s': pygame.font.Font('./fonts/minecraft.ttf', 40)
}



