import pygame
import random
import sys
import random
from src.states.BaseState import BaseState
from src.constants import *
from src.Dependency import *
from src.resources import *
from src.ShopManager import ShopManager


class SwordfishManager:
    def __init__(self, play_state):
        self.play_state = play_state
        self.swordfish_encounter = False
        self.swordfish_health = 0
        self.swordfish_damage = 0
        self.player_damage = 0

        # Load swordfish image
        self.swordfish_image = pygame.image.load("./graphics/swordfish.png").convert_alpha()
        self.swordfish_image = pygame.transform.scale(self.swordfish_image, (200, 140))  # Adjust size as needed

        # Dice button for swordfish encounter
        self.swordfish_dice_button_rect = pygame.Rect(580, 500, 120, 50)

        self.get_coins_text_timer = 0
        self.get_coins_text = "" 
        self.coin_icon = pygame.image.load("./graphics/coin.png").convert_alpha()
        self.coin_icon = pygame.transform.scale(self.coin_icon, (35,35))

        self.shop_button_rect = pygame.Rect(250, 200, 120, 50)  # Shop button

        self.roll_dice_sound = pygame.mixer.Sound("./sounds/attack.mp3")
         

    def start_battle(self, swordfish_health):
        """Start a battle with a swordfish of specific health."""
        print("Battle started!")
        self.swordfish_encounter = True
        self.swordfish_health = swordfish_health

    def roll_dice_attack(self):
        self.roll_dice_sound.play()
        """Roll dice to determine player's attack on the swordfish."""
        self.player_damage = random.randint(1, 6)  # Player's base attack damage

        if self.play_state.sword_active:
            self.player_damage *= 2  # Double damage if sword effect is active
            print(f"Sword effect active! Attack damage doubled to {self.player_damage}!")

        self.swordfish_health -= self.player_damage
        print(f"Player attacked with {self.player_damage}! swordfish health: {self.swordfish_health}")

        if self.swordfish_health <= 0:
                print("swordfish defeated!")
                self.swordfish_encounter = False  # End swordfish encounter
                coins_earned = random.randint(2, 3)
                self.play_state.money += coins_earned  # Add random currency for defeating the swordfish
                self.get_coins_text = f"swordfish killed: +{coins_earned} coins!"
                self.get_coins_text_timer = pygame.time.get_ticks()  
        else:
            self.swordfish_attack()

    def swordfish_attack(self):
        """swordfish's attack phase after the player's turn."""
        self.swordfish_damage = random.randint(2, 3)  # swordfish rolls a dice for damage

        if self.play_state.shield_active:
            self.swordfish_damage //= 2  # Halve damage if shield effect is active
            print(f"Shield effect active! swordfish damage reduced to {self.swordfish_damage}")

        self.play_state.character_hp -= self.swordfish_damage
        print(f"swordfish attacked back with {self.swordfish_damage}! Player HP: {self.play_state.character_hp}")

        if self.play_state.character_hp <= 0:
            print("Player defeated!")
            self.play_state.has_won = False
            g_state_manager.Change('game-over', {})


    def handle_click(self, event_pos):
        """Handle mouse clicks during a swordfish encounter."""
        if self.swordfish_dice_button_rect.collidepoint(event_pos):
            self.roll_dice_attack()

    def update(self, dt, events):
        for event in events:
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # Left mouse button
                    # Check if the shop button is clicked (toggle shop state)
                    if self.play_state.shop_button_rect.collidepoint(event.pos):
                        self.play_state.shop_open = not self.play_state.shop_open  # Toggle shop open state
                        return  # Return immediately to avoid other actions if shop is toggled

                     # Handle Heal button click only if Violet is selected
                    # if self.play_state.character == 1 and self.play_state.heal_button_rect.collidepoint(event.pos):
                    #     if "heal" in self.play_state.abilities and self.play_state.abilities["heal"]["count"] > 0:
                    #         if self.play_state.character_hp < 110:  # Heal only if HP is not max
                    #             heal_amount = self.play_state.abilities["heal"]["effect"]
                    #             self.play_state.character_hp = min(self.play_state.character_hp + heal_amount, 110)
                    #             self.play_state.abilities["heal"]["count"] -= 1
                    #             print(f"Healed +{heal_amount} HP. Remaining heals: {self.play_state.abilities['heal']['count']}")
                    #         else:
                    #             print("HP is already at maximum!")
                    #     else:
                    #         print("No heals remaining!")

                    # Handle Poison button click only if Ekko is selected and during a swordfish encounter
                    if self.play_state.character == 2 and self.swordfish_encounter and self.play_state.poison_button_rect.collidepoint(event.pos):
                        if "poison" in self.play_state.abilities and self.play_state.abilities["poison"]["count"] > 0:
                            # Use poison to instantly defeat the swordfish
                            self.swordfish_health = 0
                            self.swordfish_encounter = False  # End swordfish encounter
                            self.play_state.abilities["poison"]["count"] -= 1
                            print(f"Poison used! swordfish instantly defeated. Remaining poisons: {self.play_state.abilities['poison']['count']}")
                        else:
                            print("No poison uses remaining!")  


                
                    # If the shop is open, handle shop interactions only
                    if self.play_state.shop_open:
                        # Navigation between shop pages
                        if self.play_state.next_button_rect.collidepoint(event.pos):
                            if self.play_state.shop_page == 1:  # Navigate to page 2
                                self.play_state.shop_page = 2
                                print("Navigated to Shop Page 2")
                        elif self.play_state.prev_button_rect.collidepoint(event.pos):
                            if self.play_state.shop_page == 2:  # Navigate back to page 1
                                self.play_state.shop_page = 1
                                print("Navigated to Shop Page 1")

                        # Handle item purchases based on the current shop page
                        if self.play_state.shop_page == 1:
                            if self.play_state.small_potion_button_rect.collidepoint(event.pos) and self.play_state.money >= 5:
                                self.play_state.money -= 5
                                self.play_state.character_hp += 10  # Apply small potion effect
                                print("Bought Small Potion: +10 HP")
                            elif self.play_state.large_potion_button_rect.collidepoint(event.pos) and self.play_state.money >= 10:
                                self.play_state.money -= 10
                                self.play_state.character_hp += 30  # Apply large potion effect
                                print("Bought Large Potion: +30 HP")
                            elif self.play_state.extra_step_button_rect.collidepoint(event.pos) and self.play_state.money >= 25:
                                self.play_state.money -= 25
                                self.play_state.extra_step_active = True
                                print("Bought Extra Step: Extra step bonus now active!")
                            elif self.play_state.sword_button_rect.collidepoint(event.pos) and self.play_state.money >= 30:
                                self.play_state.money -= 30
                                self.play_state.sword_active = True  # Activate the Sword effect
                                print("Bought Sword: Attack rolls are now doubled!")

                        elif self.play_state.shop_page == 2:
                            if self.play_state.shield_button_rect.collidepoint(event.pos) and self.play_state.money >= 30:
                                self.play_state.money -= 30
                                self.play_state.shield_active = True  # Activate the Shield effect
                                print("Bought Shield: Incoming damage will be halved!")

                        # Check if the close button is clicked to close the shop
                        if self.play_state.close_button_rect.collidepoint(event.pos):
                            self.shop_open = False  # Close the shop
                            print("Shop closed.")

                    else:
                        # If the shop is closed, handle roll dice button click
                        if self.play_state.roll_dice_button_rect.collidepoint(event.pos) and not self.play_state.is_moving:
                            self.play_state.roll_dice()
                        

        if self.get_coins_text and pygame.time.get_ticks() - self.get_coins_text_timer > 2000:
            self.get_coins_text = ""

    def render(self, screen):
        if self.swordfish_encounter:
            overlay_image = pygame.image.load("./graphics/battle_swordfish.jpg").convert_alpha()
            # Scale the overlay image to fit the screen dimensions
            overlay_image = pygame.transform.scale(overlay_image, (WIDTH,HEIGHT))
            # Create a Surface for transparency
            overlay_surface = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            overlay_surface.fill((0, 0, 0, 90))  # RGBA (255, 255, 255, alpha)
            screen.blit(overlay_image, (0, 0))
            screen.blit(overlay_surface, (0, 0))
          
            # Display player and jellyfish images
            player_x = 225
            player_y = 150
            self.player_image = pygame.transform.scale(self.play_state.scaled_character_img, (250, 250))
            screen.blit(self.player_image, (player_x, player_y))

            swordfish_x = 825
            swordfish_y = 290
            screen.blit(self.swordfish_image, (swordfish_x, swordfish_y))

            # Render player and swordfish health
            font = gFonts['small']
            player_health_text = font.render(f"Player HP: {self.play_state.character_hp}", True, (0, 255, 0))
            screen.blit(player_health_text, (260, HEIGHT // 2 + 90))

            swordfish_health_text = font.render(f"swordfish HP: {self.swordfish_health}", True, (255, 0, 0))
            screen.blit(swordfish_health_text, (850, HEIGHT // 2 + 90))

            player_damage_text = font.render(f"Damage Dealt: {self.player_damage}", True, (255, 255, 255))
            screen.blit(player_damage_text, (260, HEIGHT // 2 + 120))

            swordfish_damage_text = font.render(f"Damage Dealt: {self.swordfish_damage}", True, (255, 255, 255))
            screen.blit(swordfish_damage_text, (850, HEIGHT // 2 + 120))
            # Render dice roll button
            pygame.draw.rect(screen, (255, 255, 255), self.swordfish_dice_button_rect)
            dice_button_text = font.render("Roll Dice", True, (0, 0, 0))
            screen.blit(dice_button_text, dice_button_text.get_rect(center=self.swordfish_dice_button_rect.center))
        
        if self.get_coins_text:
            font = gFonts['small']
            get_coin_text_surface = font.render(self.get_coins_text, True, (255, 215, 0))
            screen.blit(self.coin_icon, (290,240))  # Position coin icon to the left
            screen.blit(get_coin_text_surface,(170, 280))
            
        if self.play_state.has_won :
            g_state_manager.Change('victory', {})

        if self.play_state.character == 2 and self.swordfish_encounter:
            font = gFonts['small']
            if "poison" in self.play_state.abilities and self.play_state.abilities["poison"]["count"] > 0:
                # Active Poison button (Fresh Green)
                pygame.draw.rect(screen, (0, 255, 0), self.play_state.poison_button_rect)
                poison_text = font.render("Poison", True, (0, 0, 0))
                screen.blit(poison_text, poison_text.get_rect(center=self.play_state.poison_button_rect.center))   
                
            else:
                # Inactive Poison button (Gray)
                pygame.draw.rect(screen, (128, 128, 128), self.play_state.poison_button_rect)
                poison_text = font.render("Poison", True, (255, 255, 255))
                screen.blit(poison_text, poison_text.get_rect(center=self.play_state.poison_button_rect.center))   
        
        if self.play_state.character == 1:  # Violet
            font = gFonts['small']
            if "heal" in self.play_state.abilities and self.play_state.abilities["heal"]["count"] > 0:
                # Active Heal button (Fresh Green)
                pygame.draw.rect(screen, (0, 255, 0), self.play_state.heal_button_rect)
                heal_text = font.render("Heal", True, (0, 0, 0))
                screen.blit(heal_text, heal_text.get_rect(center=self.play_state.heal_button_rect.center))
            else:
                # Inactive Heal button (Gray)
                pygame.draw.rect(screen, (128, 128, 128), self.play_state.heal_button_rect)
                heal_text = font.render("Heal", True, (255, 255, 255))
                screen.blit(heal_text, heal_text.get_rect(center=self.play_state.heal_button_rect.center))

