import pygame
import random
from pygame import mixer
from src.constants import *
from src.Dependency import *

pygame.mixer.pre_init(44100, -16, 2, 4096)
pygame.init()

music_channel = mixer.Channel(0)
music_channel.set_volume(0.1)

from src.Dependency import *

class GameMain:
    def __init__(self):
        self.max_frame_rate = 60
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))

        self.bg_image = pygame.image.load("./graphics/background1.jpg")

        self.bg_image = pygame.transform.scale(
            self.bg_image, (WIDTH+5, HEIGHT+5))
        
        self.bg_music = pygame.mixer.Sound('sounds/music.mp3')

        g_state_manager.SetScreen(self.screen)

        states = {
            'start': StartState(),
            'play': PlayState(),
            'game-over': GameOverState(),
            'victory': VictoryState(),
            'class-select': PlayerClassSelectState()
        }
        g_state_manager.SetStates(states)

    def render_text(self, text, font, color, position):
            text_surface = font.render(text, True, color)  # Create text surface
            self.screen.blit(text_surface, position)  # Draw text on screen
            

    def PlayGame(self):
        self.bg_music.play(-1)
        clock = pygame.time.Clock()

        while True:
            pygame.display.set_caption("Dicegeon")
            
            dt = clock.tick(self.max_frame_rate) / 1000.0

            # Handle input
            events = pygame.event.get()

            # Update game state
            g_state_manager.update(dt, events)

            # Render the background directly to the screen
            self.screen.blit(self.bg_image, (0, 0))

            # Render the current state (if any)
            g_state_manager.render(self.screen)

            # Screen update
            pygame.display.update()


if __name__ == '__main__':
    main = GameMain()
    main.PlayGame()
