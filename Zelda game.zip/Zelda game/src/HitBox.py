import pygame

class Hitbox:
    def __init__(self, x, y, width, height):
        self.x=x
        self.y=y
        self.width=width
        self.height=height
        self.rect = pygame.Rect(self.x, self.y, self.width, self.height)

    def attackToPot(self, pot):
    # Create an expanded version of the hitbox by adding extra range
        expanded_hitbox = pygame.Rect(
            self.x - 10,
            self.y - 10,
            self.width + 2 * 10,
            self.height + 2 * 10
        )

        # Create the pot's rect
        pot_rect = pygame.Rect(pot.x, pot.y, pot.width, pot.height)

        # Check if the expanded hitbox collides with the pot's rect
        return expanded_hitbox.colliderect(pot_rect)