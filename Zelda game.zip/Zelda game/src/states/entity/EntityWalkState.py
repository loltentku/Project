import random

from src.states.BaseState import BaseState
from src.constants import *

class EntityWalkState(BaseState):
    def __init__(self, entity, player,dungeon=None):
        self.entity = entity
        self.entity.ChangeAnimation('down')
        self.dungeon = dungeon
        self.player = player

        #AI control
        self.move_duration = 0
        self.movement_timer = 0

        #hit wall?
        self.bumped = False

    def update(self, dt, events):
        self.bumped=False

        if self.entity.direction == "left":
            self.entity.MoveX(-self.entity.walk_speed*dt)
            if self.entity.rect.x <= MAP_RENDER_OFFSET_X + TILE_SIZE:
                #self.entity.rect.x = MAP_RENDER_OFFSET_X + TILE_SIZE
                self.entity.ChangeCoord(x=MAP_RENDER_OFFSET_X + TILE_SIZE)
                self.bumped=True
        elif self.entity.direction == "right":
            self.entity.MoveX(self.entity.walk_speed * dt)
            if self.entity.rect.x + self.entity.width >= WIDTH - TILE_SIZE * 2:
                #self.entity.rect.x = WIDTH - TILE_SIZE * 2 - self.entity.width
                self.entity.ChangeCoord(x=WIDTH - TILE_SIZE * 2 - self.entity.width)
                self.bumped=True

        elif self.entity.direction == 'up':
            self.entity.MoveY(-self.entity.walk_speed * dt)
            if self.entity.rect.y <= MAP_RENDER_OFFSET_Y + TILE_SIZE - self.entity.height /2:
                #self.entity.rect.y = MAP_RENDER_OFFSET_Y + TILE_SIZE - self.entity.height /2
                self.entity.ChangeCoord(y=MAP_RENDER_OFFSET_Y + TILE_SIZE - self.entity.height /2)
                self.bumped = True

        elif self.entity.direction == 'down':
            self.entity.MoveY(self.entity.walk_speed * dt)
            bottom_edge = HEIGHT - (HEIGHT - MAP_HEIGHT * TILE_SIZE) + MAP_RENDER_OFFSET_Y - TILE_SIZE
            if self.entity.rect.y + self.entity.height >= bottom_edge:
                #self.entity.rect.y = bottom_edge-self.entity.height
                self.entity.ChangeCoord(y=bottom_edge-self.entity.height)
                self.bumped=True

        #print(self.entity.rect.x, self.entity.rect.y, self.entity.walk_speed*dt)

    def Enter(self, params):
        pass
    def Exit(self):
        pass

    def ProcessAI(self, params, dt):
        player = self.player  

        if self.move_duration == 0 or self.bumped:
            dx = player.x - self.entity.x
            dy = player.y - self.entity.y

            if abs(dx) > abs(dy): 
                self.entity.direction = 'right' if dx > 0 else 'left'
            else: 
                self.entity.direction = 'down' if dy > 0 else 'up'

            self.move_duration = random.randint(1, 2)
            self.entity.ChangeAnimation(self.entity.direction)

        elif self.movement_timer > self.move_duration:
            self.movement_timer = 0
            self.move_duration = random.randint(1, 2)

            dx = player.x - self.entity.x
            dy = player.y - self.entity.y

            if abs(dx) > abs(dy):
                self.entity.direction = 'right' if dx > 0 else 'left'
            else:
                self.entity.direction = 'down' if dy > 0 else 'up'

            self.entity.ChangeAnimation(self.entity.direction)

        self.movement_timer += dt








    def render(self, screen):
        animation = self.entity.curr_animation.image

        screen.blit(animation, (math.floor(self.entity.rect.x - self.entity.offset_x),
                    math.floor(self.entity.rect.y - self.entity.offset_y)))