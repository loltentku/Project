import math
from src.constants import *
from src.states.BaseState import BaseState
from src.states.entity.EntityWalkState import EntityWalkState
import pygame

class PlayerCarryState(EntityWalkState):
    def __init__(self, player, dungeon):
        super(PlayerCarryState, self).__init__(player, dungeon)

        # Reference to the current room pot
        self.dungeon = dungeon
        self.pot = None  # Pot will be set dynamically

        # # Set default animation for carrying
        self.entity.ChangeAnimation("carry_down")

    def Enter(self, params):
        # Get the current pot from the room when entering the carry state
        self.pot = self.dungeon.current_room.get_active_pot()

        # Set offsets for player when entering the carry state
        self.entity.offset_y = 15
        self.entity.offset_x = 0

        # Ensure the pot's position is aligned when we enter the carry state
        self.update_pot_position()

    def update(self, dt, events):
        # Handle player movement while carrying the pot
        pressedKeys = pygame.key.get_pressed()

        if pressedKeys[pygame.K_LEFT]:
            self.entity.direction = 'left'
            self.entity.ChangeAnimation('carry_left')
        elif pressedKeys[pygame.K_RIGHT]:
            self.entity.direction = 'right'
            self.entity.ChangeAnimation('carry_right')
        elif pressedKeys[pygame.K_UP]:
            self.entity.direction = 'up'
            self.entity.ChangeAnimation('carry_up')
        elif pressedKeys[pygame.K_DOWN]:
            self.entity.direction = 'down'
            self.entity.ChangeAnimation('carry_down')
        else:
            # If no movement, switch to idle_carry state
            self.entity.ChangeState('idle_carry')

        # Constantly update the pot's position to follow the player
        self.update_pot_position()

        # Handle throwing the pot with the C key
        for event in events:
            if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                self.entity.ChangeState('throw_pot')

        # Call the parent class update (EntityWalkState) to handle bumping and other logic
        super().update(dt, events)

        # If the player is bumped into a wall, handle the bump logic (copied from PlayerWalkState)
        if self.bumped:
            self.handle_bumping(dt)

    def handle_bumping(self, dt):
        """Handle the logic when the player bumps into a wall or object."""
        if self.entity.direction == 'left':
            self.entity.x -= PLAYER_WALK_SPEED * dt
            for doorway in self.dungeon.current_room.doorways:
                if self.entity.Collides(doorway) and doorway.open:
                    self.entity.y = doorway.y + 12
                    self.dungeon.BeginShifting(-WIDTH, 0)
                    self.entity.ChangeState('walk')
            self.entity.x += PLAYER_WALK_SPEED * dt

        elif self.entity.direction == 'right':
            self.entity.x += PLAYER_WALK_SPEED * dt
            for doorway in self.dungeon.current_room.doorways:
                if self.entity.Collides(doorway) and doorway.open:
                    self.entity.y = doorway.y + 12
                    self.dungeon.BeginShifting(WIDTH, 0)
                    self.entity.ChangeState('walk')
            self.entity.x -= PLAYER_WALK_SPEED * dt

        elif self.entity.direction == 'up':
            self.entity.y -= PLAYER_WALK_SPEED * dt
            for doorway in self.dungeon.current_room.doorways:
                if self.entity.Collides(doorway) and doorway.open:
                    self.entity.y = doorway.x + 24
                    self.dungeon.BeginShifting(0, -HEIGHT)
                    self.entity.ChangeState('walk')
            self.entity.y += PLAYER_WALK_SPEED * dt

        elif self.entity.direction == 'down':
            self.entity.y += PLAYER_WALK_SPEED * dt
            for doorway in self.dungeon.current_room.doorways:
                if self.entity.Collides(doorway) and doorway.open:
                    self.entity.y = doorway.x + 24
                    self.dungeon.BeginShifting(0, HEIGHT)
                    self.entity.ChangeState('walk')
            self.entity.y -= PLAYER_WALK_SPEED * dt

    def update_pot_position(self):
        """Ensure the pot stays aligned with the player's movement."""
        if self.pot:
            self.pot.x = self.entity.x  # Stick to player's x position
            self.pot.y = self.entity.y - self.entity.height // 2  # Adjust the pot's position to be above the player

    def render(self, screen):
        # Render the player carrying the pot
        animation = self.entity.curr_animation.image
        screen.blit(animation, (math.floor(self.entity.x - self.entity.offset_x), math.floor(self.entity.y - self.entity.offset_y)))

        # Render the pot at the updated position only if not shifting rooms
        if self.pot and not self.dungeon.shifting:
            pot_image = self.pot.image[0] if isinstance(self.pot.image, list) else self.pot.image
            screen.blit(pot_image, (self.pot.x, self.pot.y))

    def Exit(self):
        pass
