import math
from src.constants import *
from src.states.BaseState import BaseState
from src.HitBox import Hitbox  
import pygame
from src.recourses import *

class PlayerThrowState(BaseState):
    def __init__(self, player, dungeon):
        self.player = player
        self.dungeon = dungeon
        self.max_throw_distance = 100  
        self.distance_travelled = 0
        self.pot = None
        self.throw_speed = 200  
        self.target_distance = self.max_throw_distance  

    def Enter(self, params):
        self.distance_travelled = 0
        self.pot = self.dungeon.current_room.get_active_pot()
        self.player.ChangeAnimation("lift_" + self.player.direction)
        direction = self.player.direction

        if direction == 'left':
            hitbox_width = 24
            hitbox_height = 48
            hitbox_x = self.pot.x - hitbox_width
            hitbox_y = self.pot.y + 6
        elif direction == 'right':
            hitbox_width = 24
            hitbox_height = 48
            hitbox_x = self.pot.x + self.pot.width
            hitbox_y = self.pot.y + 6
        elif direction == 'up':
            hitbox_width = 48
            hitbox_height = 24
            hitbox_x = self.pot.x
            hitbox_y = self.pot.y - hitbox_height
        elif direction == 'down':
            hitbox_width = 48
            hitbox_height = 24
            hitbox_x = self.pot.x
            hitbox_y = self.pot.y + self.pot.height

        self.pot_hitbox = Hitbox(hitbox_x, hitbox_y, hitbox_width, hitbox_height)

    def update(self, dt, events):
        distance_to_move = self.throw_speed * dt

        if self.distance_travelled + distance_to_move >= self.target_distance:
            distance_to_move = self.target_distance - self.distance_travelled

        if self.player.direction == 'left':
            self.pot.x -= distance_to_move
        elif self.player.direction == 'right':
            self.pot.x += distance_to_move
        elif self.player.direction == 'up':
            self.pot.y -= distance_to_move
        elif self.player.direction == 'down':
            self.pot.y += distance_to_move

        self.distance_travelled += distance_to_move
        self.update_pot_hitbox()

        for entity in self.dungeon.current_room.entities:
            if entity.CollidesWithPot(self.pot_hitbox) and not entity.invulnerable:
                entity.Damage(2)
                entity.SetInvulnerable(0.2)
                gSounds['hit_enemy'].play()
                self.remove_pot()
                return

        if self.check_wall_collision():
            gSounds['hit_enemy'].play()
            self.remove_pot()
            return

        if self.distance_travelled >= self.target_distance:
            self.player.ChangeState('walk')

    def update_pot_hitbox(self):
        """Update the position of the pot's hitbox as it moves."""
        direction = self.player.direction
        if direction == 'left':
            self.pot_hitbox.x = self.pot.x - self.pot_hitbox.width
        elif direction == 'right':
            self.pot_hitbox.x = self.pot.x + self.pot.width
        elif direction == 'up':
            self.pot_hitbox.y = self.pot.y - self.pot_hitbox.height
        elif direction == 'down':
            self.pot_hitbox.y = self.pot.y + self.pot.height

    def check_wall_collision(self):
        """Check if the pot hits any walls or boundaries of the room."""
        
        right_boundary = MAP_RENDER_OFFSET_X + MAP_WIDTH * TILE_SIZE - self.pot.width - 70
        bottom_boundary = MAP_RENDER_OFFSET_Y + MAP_HEIGHT * TILE_SIZE - self.pot.height - 70

        # Check if the pot collides with the left room boundary
        if self.pot.x <= MAP_RENDER_OFFSET_X:
            return True

        # Check if the pot collides with the right room boundary
        if self.pot.x >= right_boundary:
            return True

        # Check if the pot collides with the top room boundary
        if self.pot.y <= MAP_RENDER_OFFSET_Y:
            return True

        # Check if the pot collides with the bottom room boundary
        if self.pot.y >= bottom_boundary:
            return True

        return False





    def remove_pot(self):
        """Remove the pot from the room after the throw is complete or it hits something."""
        if self.pot in self.dungeon.current_room.pots:
            self.dungeon.current_room.pots.remove(self.pot)
        self.player.ChangeState('walk')

    def render(self, screen):
        # Render the player throwing the pot
        animation = self.player.curr_animation.image
        screen.blit(animation, (math.floor(self.player.x - self.player.offset_x), math.floor(self.player.y - self.player.offset_y)))

        # Render the pot being thrown
        if self.pot:
            pot_image = self.pot.image[0] if isinstance(self.pot.image, list) else self.pot.image
            screen.blit(pot_image, (self.pot.x, self.pot.y))

        # Uncomment to debug the hitbox:
        # pygame.draw.rect(screen, (255, 0, 255), pygame.Rect(self.pot_hitbox.x, self.pot_hitbox.y, self.pot_hitbox.width, self.pot_hitbox.height))

    def Exit(self):
        pass
