import math
from src.constants import *
from src.states.BaseState import BaseState
import pygame

class PlayerLiftState(BaseState):
    def __init__(self, player, dungeon):
        self.player = player
        self.dungeon = dungeon

    def Enter(self, params):
        # Find the nearest pot in the room
        for pot in self.dungeon.current_room.pots:
            if self.is_near_pot(self.player, pot):
                self.pot = pot  # Assign the nearest pot
                break
        
        # Update animation
        self.player.ChangeAnimation("lift_" + self.player.direction)

        # Position pot correctly when lifting
        self.update_pot_position()

    def is_near_pot(self, player, pot):
        distance = ((player.x - pot.x) ** 2 + (player.y - pot.y) ** 2) ** 0.5
        return distance < 50

    def update_pot_position(self):
        # Position the pot directly above the player while lifting
        self.pot.x = self.player.x
        self.pot.y = self.player.y - 10  # Adjust this value for positioning

    def update(self, dt, events):
        # Transition to carry state after animation finishes
        self.player.ChangeAnimation("carry_" + self.player.direction)
        if self.player.curr_animation.times_played > 0:
            self.player.curr_animation.times_played = 0
            self.player.ChangeState('carry_pot')

    def render(self, screen):
        # Render player lifting the pot
        animation = self.player.curr_animation.image
        screen.blit(animation, (math.floor(self.player.x - self.player.offset_x), math.floor(self.player.y - self.player.offset_y)))

        # Render pot
        pot_image = self.pot.image[0] if isinstance(self.pot.image, list) else self.pot.image
        screen.blit(pot_image, (self.pot.x, self.pot.y))

    def Exit(self):
        pass
