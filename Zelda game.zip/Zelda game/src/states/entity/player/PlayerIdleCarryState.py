import math
from src.constants import *
from src.states.BaseState import BaseState
from src.states.entity.EntityIdleState import EntityIdleState
import pygame

class PlayerIdleCarryState(EntityIdleState):
    def __init__(self, player, dungeon):
        super().__init__(player)  # Initialize the parent class
        self.player = player
        self.dungeon = dungeon
        self.pot = None  # Pot will be set when the player is carrying it

    def Enter(self, params):
        # Set offsets for player when entering idle state
        self.player.offset_y = 15
        self.player.offset_x = 0

        # Find the pot the player is carrying
        self.pot = self.dungeon.current_room.get_active_pot()

    def update(self, dt, events):
        pressedKeys = pygame.key.get_pressed()

        # Check for movement input and switch to carry state
        if pressedKeys[pygame.K_LEFT] or pressedKeys[pygame.K_RIGHT] or pressedKeys[pygame.K_UP] or pressedKeys[pygame.K_DOWN]:
            self.player.ChangeState('carry_pot')

        # Handle throwing the pot
        for event in events:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    self.player.ChangeState('throw_pot')

    def Exit(self):
        pass
