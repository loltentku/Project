Arcade Alternate font is created and owned by Muizz Kasim.
You are free to use this font for your own personal use or commercial use. Just provide credit where it's due. 


If needed, you can contact me at: muizzkasim@gmail.com
Thank you for downloading and enjoy the font!